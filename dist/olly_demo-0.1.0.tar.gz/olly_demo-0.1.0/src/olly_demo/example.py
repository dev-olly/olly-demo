def main():
    print("Hello, World!")

def add_three(a, b):
    return a + b + 3

def add_two(a, b):
    return a + b + 2


